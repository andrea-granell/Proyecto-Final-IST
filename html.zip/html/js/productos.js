
// Comunicación vía socket con servidor.
 const PUERTO = 8080;
 const HOST   = "http://localhost"
 const URL    = HOST + ":" + PUERTO;
 
 //Algunas variables globales.

let terc2 = "dos_tercios";
let terc1 = "un_tercio";
let columnas = [undefined,undefined];
let total_carrito = 0;

 // apertura de socket con el servidor.
 socket       = io();
 
//Leemos el alamacenado en localStorage
var lista = JSON.parse(localStorage.getItem("listaProductos"));

//pedimos los productos.
if(lista == null){
    socket.emit("peticion", false);
}else{
    socket.emit("peticion",parseInt(localStorage.getItem("Trecepcion")));
}

 socket.on("getProductos",function(datos){

    //Si es reciente, cargamos el almacenado en la sesion
    if(datos == "no"){

        datos = lista;
        //guardamos el tiempo en que se recibe
        localStorage.setItem("Trecepcion",Date.now());

    }else{
        //Guardamos la nueva lista como una cookie. 
        localStorage.setItem("listaProductos",JSON.stringify(datos));

    }
    var total_prod = datos.length;
    var cont_datos = 0;

    //Calculamos el número de filas.

    if(total_prod%2 == 1){
        var numfilas = parseInt(total_prod/2) + 1;
    }else{
        var numfilas = total_prod/2;
    }

    var pag = document.getElementById("productos");

    //Creamos tantas filas como productos tengamos. Si el numero es impar => filas = numProd + 1.

    for(var e=1;e<=numfilas;e++){

        //creamos una fila de productos y la añadimos a su clase.
        var fila = document.createElement("div");
        fila.classList.add("fila");

        //creamos las dos columnas en la que se ubicarán los dos productos.
        var izq = document.createElement("article");
        izq.classList.add(terc2);
        fila.appendChild(izq);
        columnas[0] = izq;

        //Si numero de productos impar => no añadimos el segundo en la última fila.

        var der = document.createElement("article");
        der.classList.add(terc1);
        fila.appendChild(der);
        columnas[1] = der;
        

        //Insertamos la información referente a un producto en cada columna

        for(var i=0; i<=1 ;i++){

            if(cont_datos == total_prod){
                break;
            }

            //Categoría del producto.
            var categoria = document.createElement("p");
            categoria.classList.add("categoria");
            categoria.innerHTML = datos[cont_datos].categoria;
            columnas[i].appendChild(categoria);

            columnas[i].appendChild(document.createElement("hr"));

            //Denominación de origen del producto.
            var denOrg = document.createElement("p");
            denOrg.classList.add("denominacionOrigen");
            denOrg.innerHTML = "Denominacion: " + datos[cont_datos].denominacionOrigen;
            columnas[i].appendChild(denOrg);

            //Tipo de comercio.
            var comercio = document.createElement("p");
            comercio.classList.add("comercio");
            comercio.innerHTML = datos[cont_datos].comercio;
            columnas[i].appendChild(comercio);

            //Nombre del producto.
            var nombre = document.createElement("h1");
            nombre.classList.add("nombre");
            nombre.innerHTML = datos[cont_datos].nombre;
            //Añadimos una id al nombre para poder identificar el producto.
            columnas[i].appendChild(nombre);

            //Imagen del producto.
            var imagen = document.createElement("img");
            imagen.classList.add("img");
            imagen.setAttribute("src",datos[cont_datos].img);
            //guardamos la posicion del producto en el json como atributo data de la imagen.
            imagen.setAttribute("data-id", datos[cont_datos].id);
            if(datos[cont_datos].unidades != -1){
                imagen.setAttribute("data-stock", true);
            }else{
                imagen.setAttribute("data-stock", false);
                imagen.classList.add("out_stock");
            }
            columnas[i].appendChild(imagen);

            //Precio del producto.
            var precio = document.createElement("p");
            precio.classList.add("precio");
            precio.innerHTML = datos[cont_datos].precio+" €";
            columnas[i].appendChild(precio);

            //Unidades del producto.
            var unidades = document.createElement("p");
            unidades.classList.add("unidades");
            if(datos[cont_datos].unidades > 0){
                unidades.innerHTML = datos[cont_datos].unidades+" Unidades";
            }else{
                unidades.innerHTML = "Sin estock";
            }
                columnas[i].appendChild(unidades);

            //Descripcion del producto.
            var descripcion = document.createElement("p");
            descripcion.classList.add("descripcion");
            descripcion.innerHTML = datos[cont_datos].descripcion;
            columnas[i].appendChild(descripcion);

            //Vendedor del producto.
            var vendedor = document.createElement("p");
            vendedor.classList.add("vendedor");
            vendedor.innerHTML = datos[cont_datos].vendedor;
            columnas[i].appendChild(vendedor);

            //Boton de compra
            var parr = document.createElement("p");
            parr.classList.add("ind_compra");
            parr.innerHTML = "Arrastra al carrito para comprar";
            columnas[i].appendChild(parr);
            
            pag.appendChild(fila);
            cont_datos++;

        }        
    }

     /*  Movimiento del producto     */

     for(const x of document.querySelectorAll(".img")){
        x.ondragstart = dragStart;
        x.ondrag = function(e){};
        x.ondragend = function(){};
    }

    function dragStart(e){
        e.dataTransfer.setData("text/plain/id", e.target.dataset["id"]);
        e.dataTransfer.setData("text/plain/stock", e.target.dataset["stock"]);
    }

    /*  Recepción del carrito     */

    var carrito = document.querySelector("ul:last-child");
    carrito.ondrop = dragDrop;
    carrito.ondragover = dragOver;
    carrito.ondragenter = dragEnter;
    carrito.ondragleave = dragLeave;

    function dragOver(e){
        e.preventDefault();
    }

    function dragEnter(e){
        e.preventDefault();
    }

    function dragLeave(e){
        e.preventDefault();
    }

    function dragDrop(e){
        e.preventDefault();

        //cogemos identificador del articulo.
        var newArticulo = e.dataTransfer.getData("text/plain/id");
        var disp = e.dataTransfer.getData("text/plain/stock");

        if(disp != -1){

            //Comprueba si ya se ha añadido el mismo articulo;
            var aux = 0;
            for(var x=0;x<localStorage.length;x++){

                var el = localStorage.key(x);
                if(el == "compra"+newArticulo){
                    aux = localStorage.getItem(el);
                    break;
                }
            }
            //Lo añadimos esta vez
            aux++;

            //Añadimos el producto a LocalStorage
            localStorage.setItem("compra"+newArticulo, aux);
        }
    }

 });