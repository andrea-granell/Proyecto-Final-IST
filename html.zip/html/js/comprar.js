
function comprar(socket){

    // Comunicación vía socket con servidor.
    const PUERTO = 8080;
    const HOST   = "http://localhost"
    const URL    = HOST + ":" + PUERTO;

    // apertura de socket con el servidor.
    socket       = io.connect(URL);

    //Obtenemos la lista de productos del LocalStorage.
    for(var x=0;x<localStorage.length;x++){
        var el = localStorage.key(x);

        if(el.slice(0,6) == "compra"){
            productos.push(el.slice(6,));
            cantidades.push(localStorage.getItem(el));
        }
    }

    //Enviamos al servidor los productos y cantidades de los mismos que se han comprado.
    socket.emit("compra",cantidades,productos);

    //Limpiamos del LocalStorage los productos guardados.

    for(var i=0;i<productos.length;i++){
        localStorage.removeItem("compra"+productos[i]);
    }

}