//Como crear tabla en js : Trazado de una tabla HTML mediante JavaScript y la interface DOM

//Algunas variables globales.
var num_elementos = 0;
var productos = [];
var cantidades = [];


//Obtenemos la lista de productos del LocalStorage.
for(var x=0;x<localStorage.length;x++){
    var el = localStorage.key(x);

    if(el.slice(0,6) == "compra"){
        productos.push(el.slice(6,));
        cantidades.push(localStorage.getItem(el));
    }
}

//Obtenemos la información de los productos.

var lista = JSON.parse(localStorage.getItem("listaProductos"));
console.log(lista)

//Creamos tabla y tbody de la tabla.
var tab = document.createElement("table");
tab.classList.add("muestra");
var tbod = document.createElement("tbody");

//Se añade el titulo de la tabla.
var fila = document.createElement("tr");
var titulo = document.createTextNode("Resumen de compra");
var col0 = document.createElement("th");
col0.setAttribute("colspan",3);
col0.appendChild(titulo);
fila.appendChild(col0);
tab.appendChild(fila);

var principal = document.getElementById("principal");

//Creamos las filas de la tabla.
for(var i=0; i<productos.length;i++){
console.log(parseInt(productos[i]))
    //creamos una fila.
    var fila = document.createElement("tr");

    //Creamos columna imagen.
    var imag = document.createElement("img");
    imag.setAttribute("src",lista[parseInt(productos[i])].img);
    var col1 = document.createElement("td");
    col1.classList.add("imagen");
    col1.appendChild(imag);
    fila.appendChild(col1);

    //Creamos columna nombre.
    var nom = document.createTextNode(lista[parseInt(productos[i])].nombre);
    var col2 = document.createElement("td");
    col2.classList.add("nombre");
    col2.appendChild(nom);
    fila.appendChild(col2);

    //Creamos columna unidades.
    var cantidad = document.createTextNode(cantidades[i]);
    var col3 = document.createElement("td");
    col3.classList.add("unidades");
    col3.appendChild(cantidad);
    fila.appendChild(col3);

    tbod.appendChild(fila);

    console.log("tabla")
}

tab.appendChild(tbod);
principal.appendChild(tab);

var boton = document.createElement("button");
boton.classList.add("compra");
boton.innerHTML = "Comprar";
boton.addEventListener("click", function(){

    // Comunicación vía socket con servidor.
    const PUERTO = 8080;
    const HOST   = "http://localhost"
    const URL    = HOST + ":" + PUERTO;

    // apertura de socket con el servidor.
    socket       = io();
    var productos = [];
    var cantidades = [];

    //Obtenemos la lista de productos del LocalStorage.
    for(var x=0;x<localStorage.length;x++){
        var el = localStorage.key(x);

        if(el.slice(0,6) == "compra"){
            productos.push(el.slice(6,));
            cantidades.push(localStorage.getItem(el));
        }
    }

    //Enviamos al servidor los productos y cantidades de los mismos que se han comprado.
    socket.emit("compra",cantidades,productos);
    console.log(cantidades)
    console.log(productos)

    //Limpiamos del LocalStorage los productos guardados.
    for(var i=0;i<productos.length;i++){
        localStorage.removeItem("compra"+productos[i]);
    }
    
    window.open("exitoCompra.html","_self");

},false);

var fila = document.createElement("div");
fila.classList.add("b_compra");
fila.appendChild(boton);
principal.appendChild(fila);

