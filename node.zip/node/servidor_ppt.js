
var express = require('express');
var bodyParser = require("body-parser");
var app = express();
var server = require('http').Server(app); 
var io = require('socket.io')(server);

var PUERTO =  8080;
server.listen(process.env.PORT || PUERTO, function() {
        console.log('Servidor corriendo en http://localhost:' + process.env.PORT);       
    }
);

// Para poder decodificar body en post
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
    
app.use(express.static('./html')); // directorio de documentos estáticos

let url_archivo = "./html/json/listaProductos.json";
let compra_realizada = false;

//--------------------------------

io.on('connection', function(socket) {    

    socket.on("peticion",function(x){

        if(x == false || compra_realizada == true){
            //Para leer archivos
            const fs = require('fs');
            var lectura = fs.readFileSync(url_archivo);
            
            var datos = JSON.parse(lectura);
            console.log(datos);

            socket.emit("getProductos",datos);
        }else{
            //Comprobar si el que tiene es antiguo y actualizar si o no.
            var tActual = Date.now();

            if((tActual - x) >= 120000){

                //Para leer archivos
                const fs = require('fs');
                var lectura = fs.readFileSync(url_archivo);
                
                var datos = JSON.parse(lectura);
                console.log(datos);

                socket.emit("getProductos",datos);

            }else{

                datos = "no";
                socket.emit("getProductos",datos);
            }

            console.log("compra_realizada: "+compra_realizada)
            //Comprobar si el que tiene es antiguo y actualizar si o no.
        }
    });

    socket.on("compra", function(cantidad, producto){

        //Leemos el JSON
        const fs = require('fs');
        var lectura = fs.readFileSync(url_archivo);
        
        var datos = JSON.parse(lectura);

        //Actualizamos el stock de los productos.
        console.log(producto.length)
        console.log(cantidad.length)
        for(var i=0;i<producto.length;i++){

            //Si no quedan productos
            if(datos[parseInt(producto[i])].unidades - parseInt(cantidad[i]) <= 0){
                datos[parseInt(producto[i])].unidades = -1;
            }else{
                datos[parseInt(producto[i])].unidades = datos[parseInt(producto[i])].unidades - cantidad[i];
                console.log(datos[parseInt(producto[i])].unidades)
                console.log(cantidad[i])
            }
        }

        //Escribimos la información actualizada en el JSON.
        fs.writeFileSync(url_archivo,JSON.stringify(datos));

        compra_realizada = true;
        console.log("se ha realizado una compra")

    });

});

// ------------------------------- \\

// POST: espera query con nombre eleccion
app.get('/form.html', function(req, res) {
    responder(res, req.query, "Formulario enviado correctamente");
});

function responder(res, pares, titulo) {
    res.writeHead(200, "OK", { "Content-Type": "text/html" });
    res.write("<html><head><title>" + titulo + "</title>");
    res.write("<meta charset='utf-8'></head><body>");
    res.write("<style>h1, h2{text-align:center; padding:10%;padding-bottom:0px; color:green;\n");
    res.write("</style>");
    res.write("<h1>¡Formulario enviado correctamente!</h1>");
    res.write("<h2>¡Nos pondremos en contacto contigo lo antes posible!</h2>");
    res.write("<a href='index.html' style='text-align:center; text-decoration:none; color:rgb(72, 105, 45)'> <p id = 'volver' style ='width:100%; padding-top:5%'>VOLVER</p> </a>");
    res.write("</body></html>");
    res.end();
}

console.log('Script servidor_ppt.js ejecutado');
